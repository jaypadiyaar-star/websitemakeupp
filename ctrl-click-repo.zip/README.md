# ctrl.click — Premium Beauty Portfolio Websites

Dark editorial luxury one-page site for makeup & nail artists. Single static HTML + local images. Vercel-ready.

## Stack
- Single `index.html` (no framework)
- 6 bespoke beauty editorial images in `/assets`
- `vercel.json` for clean URLs + caching

## Local preview
```bash
npx serve .
# or
python -m http.server 8000
```

## Configure
Edit top of `index.html` CONFIG:
```js
const CONFIG = {
  WHATSAPP_NUMBER: "919876543210", // no +
  PRIMARY_MSG: "Hi ctrl.click! I'm interested...",
  PROJECT_MSG: "Hi ctrl.click! I'd like to discuss...",
  EMAIL: "hello@ctrl.click",
  HANDLE: "ctrldotclick"
}
```

## Deploy to GitHub + Vercel

### 1. Push to GitHub
```bash
git init
git add .
git commit -m "feat: ctrl.click launch - all photos embedded"
git branch -M main
git remote add origin https://github.com/YOUR_USERNAME/ctrl-click.git
git push -u origin main
```

### 2. Connect Vercel
1. vercel.com → Add New Project → Import `ctrl-click` repo
2. Framework: Other (static)
3. Build Command: empty
4. Output Directory: .
5. Deploy

### 3. Custom domain
Vercel → Settings → Domains → add ctrl.click → set DNS

## Structure
```
/
├── index.html
├── vercel.json
├── README.md
├── .gitignore
└── assets/
    ├── bridal-soft-luxury.webp
    ├── bridal-veil-freckles.webp
    ├── nail-dark-chrome.webp
    ├── nail-pearl-gold.webp
    ├── editorial-gold-eye.webp
    └── portfolio-mockup.webp
```
